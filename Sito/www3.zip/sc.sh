#!/bin/sh
while true
do
sleep 10
cat index.php
done

